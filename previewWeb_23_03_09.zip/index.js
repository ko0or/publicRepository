// 전역변수
let intervalTime;

// 새로고침 시작하기
function startTimer() {
  const reloadPage = function () {
    const htmlName = document.getElementById("htmlName").value;
    if (htmlName) {
      document.getElementById("getFrame").src = htmlName + ".html";
    }
  };
  intervalTime = setInterval(reloadPage, 1000);
  
}

// 새로고침 중단하기
function stopTimer() {
  clearInterval(intervalTime);
}


// 모달창 (sweetAlert 사용)
function showModal() {
  Swal.fire({
    icon: 'info',    
    title: '사용방법 안내',
    html: 
    "해당 내용은 네이버 블로그에서 확인할 수 있습니다 <br>" +
    "관련 블로그로 이동할까요?"
    ,
    confirmButtonText: '보러가기',
    confirmButtonColor: 'skyblue',
    showCancelButton: true,
    cancelButtonColor: 'grey',
    cancelButtonText: '닫기'

  }) .then((result) => {
		  if (result.value) {
              window.open("https://blog.naver.com/taehwa10404");
		  }
    })
}